package chapter3;

public class complementSample {

	public static void main(String[] args) {
		// 보수
		/* 부호화 절대값: 양수 20, 00010100
		 * 1의 보수: 11101011
		 * 2의 보수: 11101011 + 1 = 11101100	=> -20	  
		 * 
		 */

	}

}
