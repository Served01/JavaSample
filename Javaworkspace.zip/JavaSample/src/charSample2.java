public class charSample2 {
//필드 영역
	private void charPrint() {
		
		char a = 'H';
		char b = 'Y';
		char c = 'U';
		char d = 'N';
		
		
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		System.out.println(d);
		
		String str = "HYUN";
		System.out.println(str);

		// 가(+) 감(-) 승(*) 제(/) 산(%)
		
	}
	//main영역
	public static void main(String[] args) {
		
		charSample2 cs2 = new charSample2();
		// charSample2내에서 객체를 그냥 이렇게 객체를 만든다
		
		cs2.charPrint();
		
		
	}

}

/* 다중 주석 처리 방법
 * 자바 프로그래밍
 * 클래스, 객체, 메소드 ...
 * 1.문제가 주어집니다.
 * 2.문제를 해결하기 위하여 객체를 무엇으로 할지 결정합니다.
 * 3.객체를 결정하여 사용하려면 어떤 클래스가 필요한가?
 * 4.어떤 알고리즘을 적용할 것인가? 메소드
 * 
 */