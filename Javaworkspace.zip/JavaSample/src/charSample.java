public class charSample {
	public static void main(String[] args) {
		// char sample, char 1byte 저장 가능.
		
		char a = 'H';
		char b = 'Y';
		char c = 'U';
		char d = 'N';
		
		
		System.out.println(a); // println의 ln은 줄을 바꿔준다는 의미
		System.out.println(b);
		System.out.println(c);
		System.out.println(d);
		
		String str = "HYUN"; //저장용량 무한대 (거의 무한대)
		System.out.println(str);//HYUN
		
		
	}

}