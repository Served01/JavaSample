package oop_interface;

public interface ininterface {
    
	 void add(int x, int y); 
	
	 void sub(int x, int y);
	
	public abstract void mul(int x, int y);
	
	public abstract void divi(int x, int y);
	
	public abstract void divi2(int x, int y);

}
