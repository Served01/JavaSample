package oop_inheritance2;

public class CC extends BB{
	
	public void output() {
		
  
	System.out.println("학점: "+grade);
	
	}
}

