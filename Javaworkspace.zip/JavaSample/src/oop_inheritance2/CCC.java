package oop_inheritance2;

public abstract class CCC {
	
	public abstract void output();

}
