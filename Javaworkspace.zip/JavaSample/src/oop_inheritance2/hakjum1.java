package oop_inheritance2;

public abstract class hakjum1 {
	
	public abstract void hakjum(int value);

}
