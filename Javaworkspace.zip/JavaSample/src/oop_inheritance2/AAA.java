package oop_inheritance2;

public abstract class AAA extends BBB {
	public abstract void input();

}
