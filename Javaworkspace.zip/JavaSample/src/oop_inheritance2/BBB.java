package oop_inheritance2;

public abstract class BBB extends CCC{
	public abstract void process();

}
