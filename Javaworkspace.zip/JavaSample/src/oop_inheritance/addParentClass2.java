package oop_inheritance;


//add
public abstract class addParentClass2 extends subParentClass2 {
	
	public abstract void add(int x, int y); //추상 메소드 선언하는 방법
	
	//subParentClass2: public abstract void sub(int x, int y);
	
}
