package oop_inheritance;

public abstract class divi2ParentClass2  {
	
	public abstract void divi2(int x, int y);

}
