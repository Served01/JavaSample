package oop_inheritance;


//add
public abstract class addParentClass {
	
	public abstract void add(int x, int y); //추상 메소드 선언하는 방법
	
	public abstract void sub(int x, int y);
	
	public abstract void mul(int x, int y);
	
	public abstract void divi(int x, int y);
	
	public abstract void divi2(int x, int y);
}
