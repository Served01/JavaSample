package oop_inheritance;

public abstract class diviParentClass2 extends divi2ParentClass2  {
	
	public abstract void divi(int x, int y);
	
	//divi2ParentClass2: public abstract void divi(int x, int y);

}
