package oop_inheritance;

public abstract class mulParentClass2 extends diviParentClass2 {
	
	public abstract void mul(int x, int y);
	
	//diviParentClass2: public abstract void divi(int x, int y);

}
