package oop_inheritance;

public abstract class subParentClass2 extends mulParentClass2 {
	
	public abstract void sub(int x, int y);

	//mulParentClass2: public abstract void mul(int x, int y);
}
